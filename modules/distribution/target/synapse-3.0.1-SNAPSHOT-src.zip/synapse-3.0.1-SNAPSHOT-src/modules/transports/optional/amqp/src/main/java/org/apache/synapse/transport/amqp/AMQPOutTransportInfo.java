/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.synapse.transport.amqp;

import org.apache.axis2.transport.OutTransportInfo;

import java.util.HashMap;
import java.util.Map;

public class AMQPOutTransportInfo implements OutTransportInfo {

    private String contentType;

    private Map<String, String> params = new HashMap<String, String>();

    public AMQPOutTransportInfo(String contentType, String connFacName, String queueName) {
        this.contentType = contentType;
        params.put(AMQPTransportConstant.PROPERTY_AMQP_REPLY_TO, queueName);
        params.put(AMQPTransportConstant.RESPONSE_CONNECTION_FACTORY_NAME, connFacName);
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Map<String, String> getParams() {
        return params;
    }
}
